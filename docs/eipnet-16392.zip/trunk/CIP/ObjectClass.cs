﻿
namespace EIPNET.CIP
{
    public enum ObjectClass : byte
    {
        Identity = 0x01,
        MessageRouter = 0x02,
        ConnectionObject = 0x05,
        ConnectionManager = 0x06
    }
}
